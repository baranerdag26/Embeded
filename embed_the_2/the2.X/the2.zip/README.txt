Hocam sizinle mailleşmiştik Mera'da yanımızıa gelmiştiniz.

PORTB pinlerimizden bazıları bozuk olduğu için PORTB0-3 
external interruptları kullandık. 

RB0 rotate
RB3 submit 

RG0 aşağı
RG2 sağa
RG3 yukarı
RG4 sola

şeklinde hareket sağlıyor. 
